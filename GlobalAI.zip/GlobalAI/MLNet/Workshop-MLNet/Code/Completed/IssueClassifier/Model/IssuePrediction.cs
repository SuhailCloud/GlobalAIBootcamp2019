﻿using Microsoft.ML.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public class IssuePrediction
    {
        [ColumnName("PredictedLabel")]
        public string Area { get; set; }

        public float[] Score { get; set; }
    }
}
