﻿using Microsoft.ML;
using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public class IssueLabeler
    {
        private readonly MLContext _mlContext;
        private readonly ITransformer _trainedModel;
        private readonly PredictionEngine<Issue, IssuePrediction> _predictionEngine;

        public IssueLabeler(string modelFile)
        {
            _mlContext = new MLContext();
            _trainedModel = _mlContext.Model.Load(modelFile, out var inputSchema);
            _predictionEngine = _mlContext.Model.CreatePredictionEngine<Issue, IssuePrediction>(_trainedModel);
        }

        public IssuePrediction PredictLabel(Issue issue)
        {
            var prediction = _predictionEngine.Predict(issue);
            return prediction;
        }
    }
}