﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.ML;
using Model;

namespace Website.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly PredictionEnginePool<Issue, IssuePrediction> _predictionEnginePool;

        public ValuesController(PredictionEnginePool<Issue, IssuePrediction> predictionEnginePool)
        {
            _predictionEnginePool = predictionEnginePool;
        }
        // GET api/values
        [HttpGet]
        public ActionResult<string> Get()
        {
            Issue issue = new Issue
            {
                Title = "Unify setting null CookieContainer behavior on HttpClientHandler",
                Description = "While testing XmlUriResolver, @pjanotti discovered that any segments of a file path following a '#' symbol will be cut out of Uri.LocalPath on Unix. Based on additional tests, this also occurs for the '?' symbol. This is "
            };

            var prediction = _predictionEnginePool.Predict(issue);

            var area = prediction.Area;
            return area;

        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
