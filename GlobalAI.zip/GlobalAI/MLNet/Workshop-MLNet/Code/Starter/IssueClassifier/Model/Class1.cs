﻿using System;

namespace Model
{
    public class Class1
    {
    }
}
